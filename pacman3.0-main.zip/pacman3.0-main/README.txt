PACMAN
Ex 3/3	09/01/22

Submitted by:
	Or Elkabetz - 312198179
	Ron zilberberg - 315999276

Table of Contents:
Header files:
	Board.h
	BoardNotSupportedExeption.h
	config.h
	Creture.h
	Enum.h
	Fruit.h
	Ghost.h
	GhostBest.h
	GhostGood.h
	GhostNovice.h
	InputParser.h
	InvalidGameModeException.h
	io_utils.h
	NoBoardsException.h
	Pacman.h
	Point.h
	ThePacmanGame.h
	ThePacmanGameLoad.h
	ThePacmanGameSave.h
	ThePacmanGameSilent.h
Source File:
	Board.cpp
	Fruit.cpp
	Ghost.cpp
	GhostBest.cpp
	GhostGood.cpp
	GhostNovice.cpp
	InputParser.cpp
	io_utils.cpp
	main.cpp
	Pacman.cpp
	Point.cpp
	ThePacmanGame.cpp
	ThePacmanGameLoad.cpp
	ThePacmanGameSave.cpp
	ThePacmanGameSilent.cpp

Features:
1. We have added a feature of colors, you can choose wethear to play with or without colors in the main menu.
2. Original looking pacman graphics.
3. Cool menu.
4. Cool Messages appear when eating a fruit.
5. Exceptions.
6. There is a test to each file and a final test that collect them all.

Thank you, Or and Ron.
